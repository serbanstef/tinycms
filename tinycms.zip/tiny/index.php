<?php
require_once "a55ets/s3tt1nGs.php";
$tc=new TinyCMS;
$tc->run();
?>