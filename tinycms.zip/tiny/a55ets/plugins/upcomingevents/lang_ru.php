<?php $t= array (
  'Add event' => 'Создать событие',
  'Date' => 'Дата',
  'End' => 'Окончание',
  'Event Description' => 'Описание события',
  'Event Title' => 'Заголовок события',
  'Manage Upcoming Events' => 'Управление предстоящими событиями',
  'Save Events' => 'Сохранить событие',
  'Start' => 'Начало',
  'The Event List was saved' => 'Список событий сохранен',
  'Upcoming Events' => 'Предстоящие события',
); ?>
