<?php $t= array (
  'Add event' => 'Veranstaltung hinzufügen',
  'Date' => 'Datum',
  'End' => 'Ende',
  'Event Description' => 'Beschreibung',
  'Event Title' => 'Titel',
  'Manage Upcoming Events' => 'Zukünftige Veranstaltungen bearbeiten',
  'Save Events' => 'Veranstaltungen speichern',
  'Start' => 'Start',
  'The Event List was saved' => 'Die Liste wurde gespeichert',
  'Upcoming Events' => 'Zukünftige Veranstaltungen',
); ?>