<?php $t= array (
  'Add event' => '',
  'Date' => '',
  'End' => '',
  'Event Description' => '',
  'Event Title' => '',
  'Manage Upcoming Events' => '',
  'Save Events' => '',
  'Start' => '',
  'The Event List was saved' => '',
  'Upcoming Events' => '',
); ?>