<?php $t= array (
  'Add event' => 'Adaugă eveniment',
  'Date' => 'Data',
  'End' => 'Sfârșit',
  'Event Description' => 'Descrierea evenimentului',
  'Event Title' => 'Tiltul evenimentului',
  'Manage Upcoming Events' => 'Administrare evenimente viitoare',
  'Save Events' => 'Salveaza evenimente',
  'Start' => 'Start',
  'The Event List was saved' => 'Lista de evenimente a fost salvată',
  'Upcoming Events' => 'Evenimente viitoare',
); ?>