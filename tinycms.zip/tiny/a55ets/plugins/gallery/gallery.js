$(document).ready(function() {
	$(".gal_link").fancybox({padding:0});
});